from .files import DocumentIngestor

__all__ = ["DocumentIngestor"]
