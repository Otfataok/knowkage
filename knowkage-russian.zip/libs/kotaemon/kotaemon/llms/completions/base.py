from kotaemon.llms.base import BaseLLM


class LLM(BaseLLM):
    pass
